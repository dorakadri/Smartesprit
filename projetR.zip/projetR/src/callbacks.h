#include <gtk/gtk.h>


void
on_buttonajouter_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobuttonebergement_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonrestoration_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeviewhebergement_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeviewrestoration_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonrecherche1_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttongotomodifier_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonreturn_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonrecherche2_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1serviceplusreclame_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
