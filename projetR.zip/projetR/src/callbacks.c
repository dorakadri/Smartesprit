#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"
int x,y;
void
on_buttonajouter_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *cin,*nom,*prenom,*text,*jour,*mois,*annee;
	reclamation r;
	cin=lookup_widget(objet_graphique,"entrycin");
	nom=lookup_widget(objet_graphique,"entrynom");
	prenom=lookup_widget(objet_graphique,"entryprenom");
	text=lookup_widget(objet_graphique,"entrytext");
	jour=lookup_widget(objet_graphique,"spinbuttonjour");
	mois=lookup_widget(objet_graphique,"spinbuttonmois");
	annee=lookup_widget(objet_graphique,"spinbuttonannee");
	strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
	strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(r.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(r.text,gtk_entry_get_text(GTK_ENTRY(text)));
	r.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	r.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	r.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	r.etat=x;
	if(y==1 && strlen(r.cin)==8)
	{
		ajouter_reclamation(r);
		y=0;
	}
}


void
on_radiobuttonebergement_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		x=0;

}


void
on_radiobuttonrestoration_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		x=1;
}


void
on_buttonafficher_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *windowajouter,*windowafficher,*treeviewhebergement,*treeviewrestoration;
	windowajouter=lookup_widget(objet_graphique,"windowajouter");
	windowafficher=lookup_widget(objet_graphique,"windowafficher");
	gtk_widget_destroy(windowajouter);
	windowafficher=create_windowafficher();
	gtk_widget_show(windowafficher);
	treeviewhebergement=lookup_widget(windowafficher,"treeviewhebergement");
	treeviewrestoration=lookup_widget(windowafficher,"treeviewrestoration");
	afficher_reclamation(treeviewhebergement,"reclamationH.txt");
	afficher_reclamation(treeviewrestoration,"reclamationR.txt");

}


void
on_treeviewhebergement_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkWidget *dialog1;
	GtkTreeIter iter;
	gchar *cin;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&cin,-1);
		supprimer_reclamation(cin,"reclamationH.txt");
		afficher_reclamation(treeview,"reclamationH.txt");
		dialog1=create_dialog1();
		gtk_widget_show(dialog1);
	}

}


void
on_treeviewrestoration_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkWidget *dialog1;
	GtkTreeIter iter;
	gchar *cin;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&cin,-1);
		supprimer_reclamation(cin,"reclamationR.txt");
		afficher_reclamation(treeview,"reclamationR.txt");
		dialog1=create_dialog1();
		gtk_widget_show(dialog1);
		
	}
}





void
on_buttongotomodifier_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *windowafficher,*windowajouter,*treeviewhebergement,*treeviewrestoration;
	GtkTreeModel *model;
	GtkTreeSelection *selection1,*selection2;
	GtkTreeIter iter;
	gchar *cin,*nom,*prenom,*text;
	gint jour,mois,annee,etat;
	windowajouter=lookup_widget(objet_graphique,"windowajouter");
	windowafficher=lookup_widget(objet_graphique,"windowafficher");
	treeviewhebergement=lookup_widget(windowafficher,"treeviewhebergement");
	treeviewrestoration=lookup_widget(windowafficher,"treeviewrestoration");
	selection1=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeviewhebergement));
	selection2=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeviewrestoration));
	if(gtk_tree_selection_get_selected(selection1,&model,&iter)){
		gtk_tree_model_get(model,&iter,0,&cin,1,&nom,2,&prenom,3,&text,4,&jour,5,&mois,6,&annee,-1);
		gtk_widget_destroy(windowafficher);
		windowajouter=create_windowajouter();
		gtk_widget_show(windowajouter);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowajouter,"entrycin")),cin);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowajouter,"entrynom")),nom);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowajouter,"entryprenom")),prenom);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowajouter,"entrytext")),text);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(windowajouter,"spinbuttonjour")),jour);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(windowajouter,"spinbuttonmois")),mois);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(windowajouter,"spinbuttonannee")),annee);
	}
	else if(gtk_tree_selection_get_selected(selection2,&model,&iter)){
		gtk_tree_model_get(model,&iter,0,&cin,1,&nom,2,&prenom,3,&text,4,&jour,5,&mois,6,&annee,-1);
		gtk_widget_destroy(windowafficher);
		windowajouter=create_windowajouter();
		gtk_widget_show(windowajouter);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowajouter,"entrycin")),cin);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowajouter,"entrynom")),nom);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowajouter,"entryprenom")),prenom);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowajouter,"entrytext")),text);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(windowajouter,"spinbuttonjour")),jour);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(windowajouter,"spinbuttonmois")),mois);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(windowajouter,"spinbuttonannee")),annee);
	}
	else{}

}


void
on_buttonreturn_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *windowajouter,*windowafficher;
	windowajouter=lookup_widget(objet_graphique,"windowajouter");
	windowafficher=lookup_widget(objet_graphique,"windowafficher");
	gtk_widget_destroy(windowafficher);
	windowajouter=create_windowajouter();
	gtk_widget_show(windowajouter);

}




void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		y=1;
	else
		y=0;
   	

}


void
on_buttonrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *windowafficher,*treeviewhebergement,*treeviewrestoration,*choix,*cin;
	char cin1[30];
	windowafficher=lookup_widget(objet_graphique,"windowafficher");
	choix=lookup_widget(objet_graphique,"comboboxchoix");
	cin=lookup_widget(objet_graphique,"entryrecherche1");
	treeviewhebergement=lookup_widget(windowafficher,"treeviewhebergement");
	treeviewrestoration=lookup_widget(windowafficher,"treeviewrestoration");
	strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));
	if(strcmp(cin1,"")!=0)
	{
		if(strcmp("Hebergement",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choix)))==0){
			recherche_reclamation(cin1,"reclamationH.txt");
			afficher_reclamation(treeviewhebergement,"recherche.txt");
			remove("recherche.txt");
		}
		else{
			recherche_reclamation(cin1,"reclamationR.txt");
			afficher_reclamation(treeviewrestoration,"recherche.txt");
			remove("recherche.txt");
		}
	}
	else
	{
		afficher_reclamation(treeviewhebergement,"reclamationH.txt");
		afficher_reclamation(treeviewrestoration,"reclamationR.txt");
	}
}


void
on_buttonmodifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *cin,*nom,*prenom,*text,*jour,*mois,*annee;
	reclamation r;
	cin=lookup_widget(objet_graphique,"entrycin");
	nom=lookup_widget(objet_graphique,"entrynom");
	prenom=lookup_widget(objet_graphique,"entryprenom");
	text=lookup_widget(objet_graphique,"entrytext");
	jour=lookup_widget(objet_graphique,"spinbuttonjour");
	mois=lookup_widget(objet_graphique,"spinbuttonmois");
	annee=lookup_widget(objet_graphique,"spinbuttonannee");
	strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
	strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(r.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(r.text,gtk_entry_get_text(GTK_ENTRY(text)));
	r.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	r.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	r.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	r.etat=x;
	if(y==1)
	{
		if(x==1)
		{
			modifier_reclamation(r,"reclamationR.txt");
			y=0;
		}
		else
		{
			modifier_reclamation(r,"reclamationH.txt");
			y=0;
		}
	}
}


void
on_button1serviceplusreclame_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	int r;
	GtkWidget *resultat;
	resultat=lookup_widget(objet_graphique,"label6serviceleplusreclame");
	r=service_le_plus_reclame();
	if(r==1)
		gtk_label_set_text(GTK_LABEL(resultat),"Le service le plus reclame est : Hebergement");
	else
		gtk_label_set_text(GTK_LABEL(resultat),"Le service le plus reclame est : Restauration");
}


void
on_closebutton1_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	gtk_widget_destroy(lookup_widget(objet_graphique,"dialog1"));
}

